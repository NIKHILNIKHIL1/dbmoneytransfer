package com.dws.challenge.web;

import com.dws.challenge.domain.Account;
import com.dws.challenge.domain.TransferRequest;
import com.dws.challenge.dto.response.TransferResponse;
import com.dws.challenge.exception.DuplicateAccountIdException;
import com.dws.challenge.exception.InvalidBalanceException;
import com.dws.challenge.exception.InvalidRequestException;
import com.dws.challenge.service.AccountsService;
import com.dws.challenge.service.NotificationService;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/v1/accounts")
@Slf4j
public class AccountsController {

  private final AccountsService accountsService;
  
  
  @Autowired
  public AccountsController(AccountsService accountsService) {
    this.accountsService = accountsService;
  }

  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Object> createAccount(@RequestBody @Valid @NotNull Account account) {
    log.info("Creating account {}", account);

	try {
		if(account.getBalance() == null || StringUtils.isEmpty(account.getAccountId())) {
			log.error("Invalid data entered.......");
			throw new InvalidRequestException();
		}
		
		if (account.getBalance().compareTo(BigDecimal.ZERO) <= 0) {
			log.error("Entered amount is invalid....");
			throw new InvalidBalanceException();
		}
		
		this.accountsService.createAccount(account);
	} catch (DuplicateAccountIdException daie) {
		return new ResponseEntity<>(daie.getMessage(), HttpStatus.BAD_REQUEST);
	}

	return new ResponseEntity<>(HttpStatus.CREATED);
}

  @GetMapping(path = "/{accountId}")
  public Account getAccount(@PathVariable(value = "accountId") String accountId) {
    log.info("Retrieving account for id {}", accountId);
    if(StringUtils.isEmpty(accountId)) {
		log.error("Invalid data entered.......");
		throw new InvalidRequestException();
	}
    return this.accountsService.getAccount(accountId);
  }
  
  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
  @RequestMapping("/transferMoney")
	public ResponseEntity<TransferResponse> transferMoney(@RequestBody @Valid TransferRequest request) throws Exception {
			
			this.accountsService.transferBalances(request);
			
			TransferResponse result = new TransferResponse();
			result.setAccountFromId(request.getAccountFromId());
			Account accountFrom = accountsService.getAccount(result.getAccountFromId());
			result.setBalanceAfterTransfer(accountFrom.getBalance());
			
			//this.notification.notifyAboutTransfer(accountFrom, "Dear Sir, Amount Debited");
			//this.notification.notifyAboutTransfer(accountTo, "Dear Sir, Amount Credited");
			
		return new ResponseEntity<>(result, HttpStatus.ACCEPTED);
  }
}
