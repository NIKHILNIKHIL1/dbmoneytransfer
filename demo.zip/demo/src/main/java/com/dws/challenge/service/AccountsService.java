package com.dws.challenge.service;

import com.dws.challenge.domain.Account;
import com.dws.challenge.domain.TransferRequest;
import com.dws.challenge.exception.AccountBalanceException;
import com.dws.challenge.exception.AccountNotPresentException;
import com.dws.challenge.repository.AccountsRepository;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccountsService {

	@Getter
	private final AccountsRepository accountsRepository;
	
	@Autowired
	public AccountsService(AccountsRepository accountsRepository) {
		this.accountsRepository = accountsRepository;
	}

	public void createAccount(Account account) {
		this.accountsRepository.createAccount(account);
	}

	public Account getAccount(String accountId) {
		return this.accountsRepository.getAccount(accountId);
	}

	public void transferBalances(TransferRequest transfer) {
		Account accountFrom = null;
		Account accountTo = null;
		accountFrom = accountsRepository.getAccount(transfer.getAccountFromId());
		if (accountFrom == null) {
			log.error("AccountsService.class -> Record for Account Id for from address is = "+accountFrom);
			throw new AccountNotPresentException();
		}

		accountTo = accountsRepository.getAccount(transfer.getAccountToId());
		if (accountTo == null) {
			log.error("AccountsService.class -> Record for Account Id for to address is = "+accountTo);
			throw new AccountNotPresentException();
		}

		if (accountFrom.getBalance().compareTo(transfer.getAmount()) < 0) {
			log.error("AccountsService.class -> Insufficient balance found");
			throw new AccountBalanceException();
		}

		accountFrom.setBalance(accountFrom.getBalance().subtract(transfer.getAmount()));
		accountTo.setBalance(accountTo.getBalance().add(transfer.getAmount()));
		
	}
}
