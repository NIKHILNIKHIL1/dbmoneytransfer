package com.dws.challenge.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.dws.challenge.exception.AccountBalanceException;
import com.dws.challenge.exception.InvalidBalanceException;

@ControllerAdvice
public class AccountBalanceExceptionController {
   @ExceptionHandler(value = AccountBalanceException.class)
   public ResponseEntity<Object> exception(AccountBalanceException exception) {
      return new ResponseEntity<>("Account does not have enough balance to transfer.", HttpStatus.BAD_REQUEST);
   }
   
   @ExceptionHandler(value = InvalidBalanceException.class)
   public ResponseEntity<Object> exception(InvalidBalanceException exception) {
      return new ResponseEntity<>("Invalid Amount Entered", HttpStatus.BAD_REQUEST);
   }
}