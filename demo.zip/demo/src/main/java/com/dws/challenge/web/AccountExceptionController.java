package com.dws.challenge.web;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.dws.challenge.exception.AccountNotPresentException;
import com.dws.challenge.exception.InvalidRequestException;

@ControllerAdvice
public class AccountExceptionController {
   @ExceptionHandler(value = AccountNotPresentException.class)
   public ResponseEntity<Object> exception(AccountNotPresentException exception) {
      return new ResponseEntity<>("Account does not exist.\"", HttpStatus.NOT_FOUND);
   }
   
   @ExceptionHandler(value = InvalidRequestException.class)
   public ResponseEntity<Object> exception(InvalidRequestException exception) {
      return new ResponseEntity<>("Invalid Request", HttpStatus.BAD_REQUEST);
   }
   
}
