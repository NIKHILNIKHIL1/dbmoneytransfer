package com.dws.challenge.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.dws.challenge.exception.DuplicateAccountIdException;

@ControllerAdvice
public class DuplicateAccountExceptionController {
   @ExceptionHandler(value = DuplicateAccountIdException.class)
   public ResponseEntity<Object> exception(DuplicateAccountIdException exception) {
      return new ResponseEntity<>("Account already exist", HttpStatus.BAD_REQUEST);
   }
}
