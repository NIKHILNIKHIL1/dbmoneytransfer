package com.dws.challenge.exception;

public class AccountNotPresentException extends RuntimeException {
		   private static final long serialVersionUID = 1L;
		}
