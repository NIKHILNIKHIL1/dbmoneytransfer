package com.dws.challenge.exception;

public class InvalidBalanceException extends RuntimeException {
	   private static final long serialVersionUID = 1L;
	}
