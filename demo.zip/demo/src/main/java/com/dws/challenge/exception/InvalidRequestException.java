package com.dws.challenge.exception;

public class InvalidRequestException extends RuntimeException {
	   private static final long serialVersionUID = 1L;
	}